@extends('layouts.master')

@section('title', 'Page Title')



@section('content')
<div class="row">
        <div class="col-md-12 text-center">
            <h1 class="post-title">Learning Laravel</h1>
            <p>This blog post will get you right on track with Laravel!</p>
            <p><a href="#">Read more...</a></p>
        </div>
    </div>
    <p>This is my body content.</p>
@endsection